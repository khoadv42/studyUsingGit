package com.khoadv42;

import java.io.File;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.khoadv42.controller.FileUploadController;

@SpringBootApplication
//@ComponentScan({"com.khoadv42","com.khoadv42.controller"})
public class UpLoadFileProjectApplication {
	
	public static void main(String[] args) {
//		new File(FileUploadController.uploadDirectory).mkdir();
		SpringApplication.run(UpLoadFileProjectApplication.class, args);
	}

}
